import React, { useState, useEffect } from "react";
import { Button } from "reactstrap";
import Course from "./Course"

//we have used a functional component here not a class based function
const Allcourse = () => {    // passing object course
    
    // The reason we used blank array [] is So the function we have passed in the useEffect will only execute when the component is mounted
    // and if u want it to run when the component is updated too then remove []
    useEffect( () => {
        //alert("testing");
        document.title = "View All Courses  || Shreyansh Academy";
    }, [] );   //here we have passed a blank array [] to stop the refresh after every action on the Allcourses page


    // So the setCourses function will update courses
    const [courses,setCourses] = useState([          // useState is a Hook that enables the states
                                                     // to use Class based functionallity we use hooks
        {title:"Java Course",description:"this is just testing"},     //These are array of objects
        {title:"Django Course",description:"this is demo"},
        {title:"React Course",description:"this is UI Course"},
        {title:"Angular Course",description:"this is UI Course"}
    ])    
    

    return(
        <div>
            {/* <Button onClick = { () => {     // To check the above useage of blank array []
                console.log("test");
                setCourses([...courses, {title: " Latest Course ", description: "This is demo"}, ]);
            }}>  Test  </Button> 
            */}
            <h1>All Courses</h1>
            <p>List of courses are as follows</p>

            {
               courses.length > 0 ? courses.map((item)=>(<Course course = {item} />)): "No Courses"
            }
        </div>
    )
}

export default Allcourse;
