import React from "react";

import {
    Card,
    CardBody,
    CardTitle,
    CardSubtitle,
    CardText,
    CardFooter,
    Button,
    Container,
} from "reactstrap";

const Course = ({course}) => {    // pasing object course
    return(
        <Card className="text-center">
            <CardBody>
                <CardSubtitle class="font-weight-bold">{course.title}</CardSubtitle>     {/*  {course.title} is a variable */}
                <CardText className="">{course.description}</CardText>
                <Container className="text-center">
                    <Button color="danger">Delete</Button>  {''}
                    <Button color="warning">Update</Button>
                </Container>
            </CardBody>
        </Card>
    )
}

export default Course;
